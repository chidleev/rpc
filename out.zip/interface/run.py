import web3
import json


class Run():
    def __init__(self):
        with open("abi.txt", "r") as f:
            abi = json.load(f)
        self.w3 = web3.Web3(web3.HTTPProvider('http://127.0.0.1:8545'))
        contractAddress = web3.Web3.toChecksumAddress("0xA5fF6dfacc94AFBBce672077906a866591bdFAA8")

        self.con = self.w3.eth.contract(
            abi=abi,
            address=contractAddress
        )
#желт

    def reg_users(self, adr, fio, vs, pas):
        adr = web3.Web3.toChecksumAddress(adr)
        tx = self.con.functions.registry(fio, vs).transact({"from": adr})
        self.w3.eth.waitForTransactionReceipt(tx)

    def reg_license(self, number, deadline, category, adr):
        adr = web3.Web3.toChecksumAddress(adr)
        tx = self.con.functions.reg_license(number, deadline, category).transact({"from": adr})
        self.w3.eth.waitForTransactionReceipt(tx)

    def prolong_license(self, adr):
        adr = web3.Web3.toChecksumAddress(adr)
        tx = self.con.functions.renewal_license().transact({"from": adr})
        self.w3.eth.waitForTransactionReceipt(tx)

    def reg_car(self, category, lifetime, market_price,  adr):
        adr = web3.Web3.toChecksumAddress(adr)
        tx = self.con.functions.reg_car(category, market_price, lifetime).transact({"from": adr})
        self.w3.eth.waitForTransactionReceipt(tx)

#синяя

    def get_user(self, adr):
        adr = web3.Web3.toChecksumAddress(adr)
        users = self.con.functions.get_driver_info().call({"from": adr})
        return users

r = Run()