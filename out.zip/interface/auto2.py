from uis.auto import Ui_Dialog
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import lk2
from run import Run


class Account(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        QtWidgets.QWidget.__init__(self)
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.ui.pushButton_2.clicked.connect(self.Reg)
        self.ui.pushButton.clicked.connect(self.login)
        self.note = QtWidgets.QErrorMessage()
        self.r = Run()

    def Reg(self):
        adr = self.ui.lineEdit_6.text()
        fio = self.ui.lineEdit_5.text()
        log = self.ui.lineEdit_3.text()
        pas = int(self.ui.lineEdit_4.text())
        vs = int(self.ui.lineEdit_7.text())
        self.r.reg_users(adr, log, fio, vs, pas)
        self.note.setWindowTitle("Успех")
        self.note.showMessage("Регистрация успешна")

    def login(self):
        pas = self.ui.lineEdit_2.text()
        adr = self.ui.lineEdit.text()
        self.open = lk2.Account(adr)
        self.open.show()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myapp = Account()
    myapp.show()
    sys.exit(app.exec())
