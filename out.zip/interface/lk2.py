from uis.lk import Ui_DialogLK
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import run


class Account(QtWidgets.QMainWindow):
    def __init__(self, adr):
        QtWidgets.QWidget.__init__(self)
        self.ui = Ui_DialogLK()
        self.ui.setupUi(self)
        self.run = run.Run()
        self.adr = adr
        self.ui.pushButton.clicked.connect(self.reg_license)
        self.ui.pushButton_2.clicked.connect(self.prolong_license)
        self.ui.pushButton_3.clicked.connect(self.reg_car)
        self.info()
        self.note = QtWidgets.QErrorMessage()

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.info)
        self.timer.start(3000)

    def info(self):
        self.balanc = self.run.w3.eth.getBalance(self.adr)
        self.ui.label_5.setText(str(self.balanc / 10 ** 18) + " ETH")
        user = self.run.get_user(self.adr)
        self.ui.label_4.setText(str(user[0]))
        self.ui.label_14.setText(str(user[2]))

    def reg_license(self):
        try:
            nomer = int(self.ui.lineEdit.text())
            sroc = int(self.ui.lineEdit_2.text())
            kateg = self.ui.lineEdit_3.text()
            if kateg == "A":
                kateg = 1
            if kateg == "B":
                kateg = 2
            if kateg == "C":
                kateg = 3
            ad = self.run.lisenses(nomer)[3]
            if ad == '0x0000000000000000000000000000000000000000':
                self.run.reg_license(nomer, sroc, kateg, self.adr)
                self.note.setWindowTitle("Успех")
                self.note.showMessage("Добавлено успешно")
            else:
                self.note.setWindowTitle("Ошибка")
                self.note.showMessage("Лицензия занята")
        except:
            self.note.setWindowTitle("Ошибка")
            self.note.showMessage("Проверьте данные")

    def prolong_license(self):
        user = self.run.get_user(self.adr)
        kl = user[5]
        if kl == 0:
            nomer = user[2]
            self.run.prolong_license(self.adr)
            li = self.run.lisenses(nomer)
            self.ui.label_11.setText(str(li[1]))
            self.note.setWindowTitle("Успех")
            self.note.showMessage("Продление успешно")
        else:
            self.note.setWindowTitle("Ошибка")
            self.note.showMessage("Оплатите штраф")

    def reg_car(self):
        try:
            category = self.ui.lineEdit_4.text()
            if category == "A":
                category = 1
            if category == "B":
                category = 2
            if category == "C":
                category = 3
            user = self.run.get_user(self.adr)
            cat = self.run.lisenses(user[2])[2]
            if category == cat:
                lifetime = int(self.ui.lineEdit_6.text())
                market_price = int(self.ui.lineEdit_5.text())
                self.run.reg_car(category, lifetime, market_price, self.adr)

                lifetime = user[8]
                market_price = user[9]
                self.ui.label_28.setText(str(lifetime))
                self.ui.label_27.setText(str(market_price))
                self.note.setWindowTitle("Успех")
                self.note.showMessage("ТС успешно добавлено")
            else:
                self.note.setWindowTitle("Ошибка")
                self.note.showMessage("Вы не имеете необходимой категориеи")
        except:
            self.note.setWindowTitle("Ошибка")
            self.note.showMessage("Проверьте данные")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myapp = Account("0x97Eb8f294c9F4DA740c7902B999dDF7629D13E93")
    myapp.show()
    sys.exit(app.exec())
