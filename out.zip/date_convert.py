import datetime, time
datetime = datetime.datetime(2030, 3, 31)
print(int(time.mktime(datetime.timetuple())))
print(datetime.strftime('%Y/%m/%d'))
